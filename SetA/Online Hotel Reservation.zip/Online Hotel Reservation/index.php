<?php require 'db.php'; ?>

<!DOCTYPE html>

<html>
<head>
<link href="css/index.css" type="text/css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <style type="text/css">
	#position{
                background-image: url("images/hotel.jpg");
	           
 </style>
<title>Hotel Reservation</title>
</head>

<body>
<div id="position">
<img src="images/Capture.jpg">
<fieldset>
<form name = "myForm" method="post">
<table >

	<tr>
		<td class="a">Name: </td>
		<td><input type="text" name="Name" placeholder="Name" /></td>
	</tr>
	<tr>
		<td class="b">Address: </td>
		<td><input type="text" name="Address" placeholder="Address" /></td>
	</tr>
	<tr>
		<td class="c">Mobile Number: </td>
		<td><input type="text" name="Mobile" placeholder="Mobile" /></td>
	</tr>
	<tr>
		<td class="d">Email: </td>
		<td><input type="text" name="Email" placeholder="Email" /></td>
	</tr>
	<tr>
		<td class="e">Date of Stay: </td>
		<td><input type="text" name="Dos" placeholder="Date of Stay" /></td>
	</tr>
	<tr>
		<td class="f">End of Stay: </td>
		<td><input type="text" name="Eos" placeholder="End of Stay" /></td>
	</tr>
	<tr>
		<td class="g">No. of days of stay: </td>
		<td><input type="text" name="ndos" placeholder="No. of days of stay" /></td>
	</tr>
	<tr>
	
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="ADD" /></td>
	</tr>
</table>
<?php
if (isset($_POST['submit']))

	{	   
			 		$Name=$_POST['Name'] ;
					$Address= $_POST['Address'] ;					
					$Mobile=$_POST['Mobile'] ;
					$Email=$_POST['Email'] ;
					$Dos=$_POST['Dos'] ;
					$Eos=$_POST['Eos'] ;
					$ndos=$_POST['ndos'] ;
												
					$query = $dbc->prepare("INSERT INTO books (Name,Address,Mobile,Email,Dos,Eos,ndos) 
						VALUES (:Name,:Address,:Mobile,:Email,:Dos,:Eos,:ndos)");
					$query->execute(array(':Name'=>$Name,
								          ':Address'=>$Address,
									      ':Mobile'=>$Mobile,
									      ':Email'=>$Email,
										  ':Dos'=>$Dos,
										  ':Eos'=>$Eos,
										  ':ndos'=>$ndos,));
										 
				
	}    
?>
</form>
<table cellpadding="0" width="500" border="1" cellspacing="0">
	
			<?php
				
			$results=$dbc->query("SELECT * FROM books");
			$results->execute();
			$results = $results->fetchAll(PDO::FETCH_ASSOC);
			foreach ($results as $result){
				
				$id = $result['HotelID'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$result['HotelID']."</font></td>";
				echo"<td width='100'><font color='black'>" .$result['Name']."</font></td>";
				echo"<td width='100'><font color='black'>". $result['Address']. "</font></td>";
				echo"<td width='100'><font color='black'>". $result['Mobile']. "</font></td>";
				echo"<td width='100'><font color='black'>". $result['Email']. "</font></td>";	
				echo"<td width='100'><font color='black'>". $result['Dos']. "</font></td>";
				echo"<td width='100'><font color='black'>". $result['Eos']. "</font></td>";
				echo"<td width='100'><font color='black'>". $result['ndos']. "</font></td>";
				echo"<td> <a href ='view.php?HotelID=$id'> Edit</a>";
				echo"<td> <a href ='del.php?HotelID=$id'><center>Delete</center></a>";
				echo "</tr>";
				
			}
	
			?>
</table>
</fieldset>
</div>
</body>

</html>
