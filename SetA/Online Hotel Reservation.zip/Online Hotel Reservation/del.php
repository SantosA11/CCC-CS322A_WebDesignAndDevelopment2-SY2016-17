<?php
  include("db.php");  

	$id =$_REQUEST['HotelID'];
	
	
	// sending query
	$query= $dbc->query("DELETE FROM books WHERE HotelID = '$id' ");
	$query->execute();
	header("Location: index.php");
?>