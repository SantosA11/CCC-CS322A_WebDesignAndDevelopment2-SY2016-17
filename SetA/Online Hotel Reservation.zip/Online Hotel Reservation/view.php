<?php
require("db.php");
$id =$_REQUEST['HotelID'];


$query = $dbc->query("SELECT * FROM books WHERE HotelID = '$id'");
$query->execute();
$query=$query->fetch(PDO::FETCH_ASSOC);

				$Name=$query['Name'] ;
				$Address= $query['Address'] ;					
				$Mobile=$query['Mobile'] ;
				$Email=$query['Email'] ;
				$Dos=$query['Dos'] ;
				$Eos=$query['Eos'] ;
				$ndos=$query['ndos'] ;

if(isset($_POST['save'])){	
	$Name_save = $_POST['Name'];
	$Address_save = $_POST['Address'];
	$Mobile_save = $_POST['Mobile'];
	$Email_save = $_POST['Email'];
	$Dos_save = $_POST['Dos'];
	$Eos_save = $_POST['Eos'];
	$ndos_save = $_POST['ndos'];

		$update = $dbc->query("UPDATE books SET Name ='$Name_save', Address ='$Address_save',
		 Mobile ='$Mobile_save',Email ='$Email_save',Dos ='$Dos_save',Eos ='$Eos_save',ndos ='$ndos_save' WHERE HotelID = '$id'");
			$update->execute();
			if($update){
					echo "<script>alert('DATA SUCCESFULY UPDATED !');
					self.location='index.php'</script>";
			}
		
}

?>
<!DOCTYPE html >
<html >
<head>
<link href="css/view.css" type="text/css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
#position{
                background-image: url("images/hotel.jpg");
	            background-repeat: no-repeat;}
 </style>
<title>Untitled Document</title>
</head>

<body>
<div id="position">
<img src="images/Capture.jpg">
<fieldset>
<form method="post">
<table>
	<tr>
		<td >Name:</td>
		<td><input type="text" name="Name" value="<?php echo $Name ?>"/></td>
	</tr>
	<tr>
		<td>Address</td>
		<td><input type="text" name="Address" value="<?php echo $Address ?>"/></td>
	</tr>
	<tr>
		<td>Mobile</td>
		<td><input type="text" name="Mobile" value="<?php echo $Mobile ?>"/></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><input type="text" name="Email" value="<?php echo $Email ?>"/></td>
	</tr>
	<tr>
		<td>Date of Stay</td>
		<td><input type="text" name="Dos" value="<?php echo $Dos ?>"/></td>
	</tr>
	<tr>
		<td>End of Stay</td>
		<td><input type="text" name="Eos" value="<?php echo $Eos ?>"/></td>
	</tr>
	<tr>
		<td>No. of days of stay</td>
		<td><input type="text" name="ndos" value="<?php echo $ndos ?>"/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>
</fieldset>
</div>
</body>
</html>